#include "telebot/cli/cli.h"

int main(int argc, char** argv) {
    return telebot::cli::main_cli(argc, argv);
}
