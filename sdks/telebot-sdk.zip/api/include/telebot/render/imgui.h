#pragma once

namespace telebot::render::imgui {

void build();

} // namespace telebot::render::imgui
